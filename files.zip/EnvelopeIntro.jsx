'use client';
import { useEffect, useRef, useState } from 'react';
import './envelope-intro.css';

const FLOWERS = [[8, 12, .34, 10], [23, 27, .2, -20], [93, 15, .3, 30], [79, 33, .18, 5],
  [6, 160, .36, -15], [21, 171, .2, 25], [92, 149, .34, 0], [76, 168, .22, -30]];
const PETALS = ['14%', '34%', '55%', '74%', '90%'];
const DUST = ['10%', '22%', '31%', '46%', '58%', '67%', '80%', '92%'];
const SPARKS = Array.from({ length: 16 }, (_, i) => i * 22.5);
const FLAP_PATH = 'M0,0 H860 L430,342 Z';

function Flower({ x, y, s, r, i }) {
  return (
    <g transform={`translate(${x} ${y}) rotate(${r}) scale(${s})`}>
      <g className="ei-sway" style={{ animationDelay: `${-i * 1.3}s` }}>
        {[0, 72, 144, 216, 288].map((a) => (
          <ellipse key={a} cx="0" cy="-24" rx="15" ry="27" transform={`rotate(${a})`}
            fill="url(#ei-pet)" stroke="#e2d4bc" strokeWidth=".7" />
        ))}
        <circle r="7" fill="#c98a2c" />
        {[0, 45, 90, 135, 180, 225, 270, 315].map((a) => (
          <g key={a} transform={`rotate(${a})`}>
            <line y2="-15" stroke="#e8a33a" strokeWidth="1.2" /><circle cy="-16" r="2" fill="#e8a33a" />
          </g>
        ))}
      </g>
    </g>
  );
}

function Defs() {
  return (
    <svg width="0" height="0" style={{ position: 'absolute' }} aria-hidden="true">
      <defs>
        <radialGradient id="ei-pet" cx=".5" cy=".85" r=".9">
          <stop offset="0" stopColor="#e6d8bf" /><stop offset=".6" stopColor="#fffdf8" /><stop offset="1" stopColor="#fff" />
        </radialGradient>
        <radialGradient id="ei-waxred" cx=".35" cy=".3" r=".9"><stop offset="0" stopColor="#8a2640" /><stop offset=".55" stopColor="#4f0f22" /><stop offset="1" stopColor="#2a0510" /></radialGradient>
        <radialGradient id="ei-gold" cx=".35" cy=".3" r=".85">
          <stop offset="0" stopColor="#f7e4a8" /><stop offset=".45" stopColor="#cfa650" /><stop offset="1" stopColor="#7d581a" />
        </radialGradient>
        <linearGradient id="ei-ivory" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#fcf6e8" /><stop offset="1" stopColor="#eadfc6" />
        </linearGradient>
        <linearGradient id="ei-ivory2" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#f4e9d1" /><stop offset="1" stopColor="#dccba7" />
        </linearGradient>
        <linearGradient id="ei-liner" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#d9c7a0" /><stop offset="1" stopColor="#efe3c9" />
        </linearGradient>
        <filter id="ei-paper" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency=".8" numOctaves="2" result="n" />
          <feDiffuseLighting in="n" lightingColor="#fff" surfaceScale="1.4" result="l">
            <feDistantLight azimuth="225" elevation="62" />
          </feDiffuseLighting>
          <feComposite in="SourceGraphic" in2="l" operator="arithmetic" k1="1.15" k2="0" k3="0" k4="0" />
        </filter>
        <filter id="ei-wax" x="-10%" y="-10%" width="120%" height="120%">
          <feTurbulence type="fractalNoise" baseFrequency=".06" numOctaves="2" seed="3" result="t" />
          <feDisplacementMap in="SourceGraphic" in2="t" scale="7" />
        </filter>
        <filter id="ei-noise"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" /></filter>
        <pattern id="ei-damask" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M20 4Q28 12 20 20Q12 12 20 4ZM20 20Q28 28 20 36Q12 28 20 20ZM4 20Q12 12 20 20Q12 28 4 20ZM20 20Q28 12 36 20Q28 28 20 20Z"
            fill="none" stroke="#b79a5f" strokeWidth=".8" opacity=".4" />
        </pattern>
      </defs>
    </svg>
  );
}

export default function EnvelopeIntro({
  onOpen,
  lead = 'You are lovingly invited to witness',
  a = 'RISHMA',
  b = 'MALLI',
  mono = 'RishmaMalli',
  cta = 'Open Invitation',
  logo = '/MR-logo-gold.png', // put the logo file in /public
}) {
  const [stage, setStage] = useState(0); // 1 flap · 2 rise · 3 reveal · 4 done
  const [leave, setLeave] = useState(false);
  const timers = useRef([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const start = () => {
    if (stage) return;
    setStage(1);
    [[900, 2], [2400, 3], [4000, 4]].forEach(([t, s]) => timers.current.push(setTimeout(() => setStage(s), t)));
  };
  const finish = () => {
    setLeave(true);
    timers.current.push(setTimeout(() => onOpen?.(), 900));
  };
  const cls = ['ei-root', stage >= 1 && 'is-flap', stage >= 2 && 'is-rise', stage >= 3 && 'is-reveal',
    stage >= 4 && 'is-done', leave && 'is-leave'].filter(Boolean).join(' ');

  return (
    <div className={cls} role="region" aria-label="Wedding invitation envelope">
      <Defs />
      <div className="ei-stage">
        <svg className="ei-bg" viewBox="0 0 100 177" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
          <rect width="100" height="177" fill="#4a0d1f" />
          <rect width="100" height="177" fill="url(#ei-vig)" />
          <rect width="100" height="177" filter="url(#ei-noise)" opacity=".16" style={{ mixBlendMode: 'overlay' }} />
          <defs><radialGradient id="ei-vig" cx=".5" cy=".45" r=".75">
            <stop offset="0" stopColor="#8a2640" /><stop offset=".6" stopColor="#5a1228" /><stop offset="1" stopColor="#2c0611" />
          </radialGradient></defs>
          {FLOWERS.map(([x, y, s, r], i) => <Flower key={i} x={x} y={y} s={s} r={r} i={i} />)}
        </svg>
        {PETALS.map((x, i) => <i key={'p' + i} className="ei-petal" style={{ '--x': x, '--d': `${11 + i * 1.7}s`, '--w': `${i * -2.6}s` }} />)}
        {DUST.map((x, i) => <i key={'d' + i} className="ei-dust" style={{ '--x': x, '--d': `${7 + (i % 4) * 2}s`, '--w': `${i * -1.4}s` }} />)}

        <div className="ei-env" onClick={start}>
          <svg className="ei-layer ei-back" viewBox="0 0 860 590" preserveAspectRatio="none">
            <rect width="860" height="590" rx="12" fill="url(#ei-liner)" filter="url(#ei-paper)" />
          </svg>

          <div className="ei-card">
            <div className="ei-frame">
              <i className="ei-c ei-c1" /><i className="ei-c ei-c2" /><i className="ei-c ei-c3" /><i className="ei-c ei-c4" />
              <p className="ei-lead">{lead}</p>
              <p className="ei-name ei-foil">{a}</p>
              <p className="ei-plus ei-foil">+</p>
              <p className="ei-name ei-foil">{b}</p>
              <div className="ei-orn"><span /><b>◆</b><span /></div>
              <p className="ei-eq ei-foil">=</p>
              <p className="ei-mono ei-foil">{mono}</p>
            </div>
          </div>

          <svg className="ei-layer ei-front" viewBox="0 0 860 590" preserveAspectRatio="none">
            <path d="M0,0 L430,342 L860,0 V578 Q860,590 848,590 H12 Q0,590 0,578 Z" fill="url(#ei-ivory2)" filter="url(#ei-paper)" />
            <path d="M0,0 L430,342 L860,0 V578 Q860,590 848,590 H12 Q0,590 0,578 Z" fill="url(#ei-damask)" />
            <path d="M2,588 L420,300 M858,588 L440,300" stroke="#8a6c34" strokeOpacity=".22" strokeWidth="2" fill="none" />
          </svg>

          <div className="ei-flapw">
            <svg className="ei-layer ei-flap-out" viewBox="0 0 860 342" preserveAspectRatio="none">
              <path d={FLAP_PATH} fill="url(#ei-ivory)" filter="url(#ei-paper)" />
              <path d={FLAP_PATH} fill="url(#ei-damask)" />
              <path d="M16,10 L430,316 L844,10" fill="none" stroke="#c49a45" strokeWidth="4" strokeLinecap="round" strokeDasharray="0 9" />
            </svg>
            <svg className="ei-layer ei-flap-in" viewBox="0 0 860 342" preserveAspectRatio="none">
              <path d={FLAP_PATH} fill="url(#ei-liner)" filter="url(#ei-paper)" />
              <path d={FLAP_PATH} fill="url(#ei-damask)" opacity=".7" />
            </svg>
          </div>

          <div className="ei-seal">
            <svg viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="46" fill="url(#ei-waxred)" filter="url(#ei-wax)" />
              <circle cx="50" cy="50" r="38" fill="none" stroke="#e4c57a" strokeOpacity=".55" strokeWidth="1" />
            </svg>
            <img className="ei-logo" src={logo} alt="MR monogram" />
            <span className="ei-sheen" />
          </div>
        </div>

        {SPARKS.map((d) => <i key={d} className="ei-spark" style={{ '--a': `${d}deg` }} />)}
        <p className="ei-hint">Tap the seal to open</p>
        <button className="ei-cta" onClick={finish}>{cta}</button>
      </div>
    </div>
  );
}
